make clean
make
./ansi_c tbird.c
