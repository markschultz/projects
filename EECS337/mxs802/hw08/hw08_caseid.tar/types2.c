/*
 *	all these type examples shall generate an error message
 */
short;
long;
signed;
unsigned;
float;
double;
void unsigned char;
unsigned float int;
unsigned char int;
unsigned char unsigned int;
short long signed unsigned float double void char;
