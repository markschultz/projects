make clean
make
./ansi_c +d types1.c
./ansi_c +d types2.c
./ansi_c +d types3.c
