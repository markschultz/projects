main()
{
/*
 *	test decimal zero
 */
	int i = 0;
	return i;
}

