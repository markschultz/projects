int	main( int argc, char *argv[])
{
	char c;	   /* char */
	int x;	/* hex */
	int o;	/* octal */
/*
 *	some other ways to encode a three
 */
	c = '\x003';
	c = '\x0003';
	c = '\x00003';
	c = '\x000003';
	x = 0x003;
	x = 0x0003;
	x = 0x00003;
	x = 0x000003;
	x = 0x0000003;
	x = 0x00000003;
	x = 0x000000003;
	o = 0003;
	o = 00003;
	o = 000003;
	o = 0000003;
	o = 00000003;
	o = 000000003;
	o = 0000000003;
	o = 00000000003;
	o = 000000000003;
/*
 *	return 3
 */
	return 3;
}
