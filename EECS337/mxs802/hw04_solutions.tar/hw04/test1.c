int	main( int argc, char *argv[])
{
	char	c;
/*
 *	test char SPACE to ~
 */
	c = ' ';
	printf( "c: %02.2x\n", c);
	c = '~';
	printf( "c: %02.2x\n", c);
/*
 *	return success
 */
	return 0;
}

