/*
 *	all these typdef examples shall be supported
 */
typedef char CHAR_TYPE;
typedef int INT_TYPE;
CHAR_TYPE;
INT_TYPE;
