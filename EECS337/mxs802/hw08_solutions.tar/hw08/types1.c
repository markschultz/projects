/*
 *	the only types supported for the ansi_c compiler:
 */
void;
char;
int;
unsigned char;
unsigned int;
