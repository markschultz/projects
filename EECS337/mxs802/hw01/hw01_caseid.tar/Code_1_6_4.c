/*******************************************************************************
*
* FILE:		Code_1_6_4.c
*
* DESC:		EECS 337 Homework Assignment 1
*
* AUTHOR:	caseid
*
* DATE:		August 26, 2010
*
* EDIT HISTORY:	
*
*******************************************************************************/

/*
 *	enter the sample code from 1.6.4
 */
