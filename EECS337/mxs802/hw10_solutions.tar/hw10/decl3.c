char a,b,c;
