char c = 1;
