int	w, x, y, z;
int i = 4; int j = 5;
