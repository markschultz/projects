char a,b,c = 3;
