make clean
make
./ansi_c decl1.c
./ansi_c decl2.c
./ansi_c decl3.c
./ansi_c decl4.c
./ansi_c decl5.c
