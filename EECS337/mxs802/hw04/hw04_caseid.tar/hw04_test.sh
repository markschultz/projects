#
#	run the test script
#
make clean
make
./ansi_c +d ../hw01/Code_1_6_1.c
./ansi_c +d ../hw01/Code_1_6_2.c
./ansi_c +d ../hw02/Code_1_6_4.cpp
./ansi_c +d test1.c
./ansi_c +d test2.c
./ansi_c +d test3.c
./ansi_c +d test4.c
./ansi_c +d test5.c
./ansi_c +d test6.c
./ansi_c +d test7.c
./ansi_c +d test8.c
./ansi_c +d test9.c
./ansi_c +d warning1.c
./ansi_c +d warning2.c
./ansi_c error1.c
./ansi_c error2.c
