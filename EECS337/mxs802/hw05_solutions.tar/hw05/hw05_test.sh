make clean
make
./ansi_c +d ../hw01/Code_1_6_1.c
./ansi_c +d ../hw01/Code_1_6_2.c
./ansi_c +d ../hw02/Code_1_6_4.cpp
