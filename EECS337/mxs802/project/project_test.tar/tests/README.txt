README.txt
EECS337 Final Project
November 16, 2010
Professor Oldham

A number of example programs and test scripts are included with this
tar file. Both c++ and c output samples are provided.

Makefile builds the examples but only compiles Test0.cpp and Test0.c 

Test0.java is a minimum Java class example with no main method.

Test1.java is a minimum Java example with a main method. This exmaple
will compile and run with no output.

Test2.java is a Java example with a string declaration and output.

Test3.java is a Java example with a constructor method.

