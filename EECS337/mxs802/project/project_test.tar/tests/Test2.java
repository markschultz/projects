class Test2 {
  public static void main(String[] args) {
    String says = "Test2 says";
    System.out.println( says);
    return;
  }
} 
