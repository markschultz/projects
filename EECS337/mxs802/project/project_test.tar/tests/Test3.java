class Test3 {
    String says;
    Test3( String _says) {
      says = _says;
    }
  public static void main(String[] args) {
      Test3 test3 = new Test3( "Test3 says");
      System.out.println( test3.says);
      return;
  }
} 
