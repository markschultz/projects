make clean
make
./java2cpp < Program.java > Program.cpp
