#include <stdio.h>
struct Test2 {
};

int main(int argc, char *argv[])
{
  char *says = "Test2 says";
  printf( "%s\n", says);
  return 0;
}
