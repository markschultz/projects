struct Test0 {
};
