make clean
make
./java2c < Test1.java > Test1.c
./java2c < Test2.java > Test2.c
./java2c < Test3.java > Test3.c
