class Test1 {
  public:
};

int main(int argc, char *argv[])
{
	return 0;
}
