make clean
make
./java2cpp < Test1.java > Test1.cpp
./java2cpp < Test2.java > Test2.cpp
./java2cpp < Test3.java > Test3.cpp
