#include <iostream> // Required for stream output (cout).
#include <string> // Required for string class.
using namespace std;

class Test2 {
  public:
};

int main(int argc, char *argv[])
{
  string says = "Test2 says";
  cout << says << endl;
  return 0;
}
